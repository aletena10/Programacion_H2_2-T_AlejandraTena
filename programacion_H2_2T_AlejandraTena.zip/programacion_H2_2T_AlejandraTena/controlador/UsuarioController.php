<?php
// Inicia la sesión para poder usar variables de sesión
session_start();

// Se incluye el archivo que contiene la clase Usuario para poder trabajar con la autenticación y registro de usuarios
require_once "../modelo/usuario.php";

// Verifica si el método de la solicitud es POST (se ha enviado un formulario)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Lógica para el registro de un nuevo usuario
    if (isset($_POST['registro'])) {
        // Intenta registrar al nuevo usuario utilizando el método estático 'registrar' de la clase Usuario
        if (Usuario::registrar($_POST['nombre'], $_POST['email'], $_POST['password'])) {
            // Si el registro es exitoso, redirige a la página de login
            header("Location: ../vista/login.php");
        } else {
            // Si hay un error al registrar el usuario, muestra un mensaje de error
            echo "Error al registrar usuario.";
        }
    }

    // Lógica para iniciar sesión con un usuario existente
    if (isset($_POST['login'])) {
        // Intenta autenticar al usuario con el correo y la contraseña proporcionados
        $usuario = Usuario::autenticar($_POST['email'], $_POST['password']);
        
        // Si el usuario es autenticado correctamente, se guarda en la sesión
        if ($usuario) {
            $_SESSION['usuario'] = $usuario;
            // Redirige al panel de control (dashboard) si las credenciales son correctas
            header("Location: ../vista/dashboard.php");
        } else {
            // Si las credenciales son incorrectas, muestra un mensaje de error
            echo "Credenciales incorrectas.";
        }
    }
}
?>


