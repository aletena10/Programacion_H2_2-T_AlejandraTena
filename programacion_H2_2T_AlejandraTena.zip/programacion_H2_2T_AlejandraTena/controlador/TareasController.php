<?php
// Inicia una sesión para poder usar variables de sesión
session_start();

// Se incluye el archivo que contiene la clase Tarea para poder trabajar con las tareas en la base de datos
require_once "../modelo/tarea.php";

// Verifica si el usuario está autenticado, si no, redirige a la página de login
if (!isset($_SESSION['usuario'])) {
    header("Location: ../vista/login.php");
    exit; // Termina el script si el usuario no está autenticado
}

// Obtiene el ID del usuario autenticado desde la sesión
$usuario_id = $_SESSION['usuario']['id'];

// Verifica si el método de la solicitud es POST, lo que indica que el usuario ha enviado un formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Lógica para agregar una tarea
    if (isset($_POST['agregar']) && !empty($_POST['titulo'])) {
        // Filtra y limpia el título de la tarea recibida del formulario
        $titulo = trim(filter_input(INPUT_POST, 'titulo', FILTER_SANITIZE_STRING));

        // Intenta agregar la tarea al sistema a través del método estático 'agregar' de la clase Tarea
        if (Tarea::agregar($usuario_id, $titulo)) {
            // Si se agrega correctamente, redirige a la página de tareas
            header("Location: ../vista/tareas.php");
            exit; // Detiene la ejecución del script
        } else {
            // Si hay un error al agregar la tarea, muestra un mensaje de error
            echo "Error al agregar la tarea.";
        }
    }

    // Lógica para eliminar una tarea
    if (isset($_POST['eliminar']) && isset($_POST['id'])) {
        // Obtiene el ID de la tarea que se va a eliminar
        $id = intval($_POST['id']);

        // Intenta eliminar la tarea a través del método estático 'eliminar' de la clase Tarea
        if (Tarea::eliminar($id)) {
            // Si se elimina correctamente, redirige a la página de tareas
            header("Location: ../vista/tareas.php");
            exit; // Detiene la ejecución del script
        } else {
            // Si hay un error al eliminar la tarea, muestra un mensaje de error
            echo "Error al eliminar la tarea.";
        }
    }

    // Lógica para actualizar el estado de una tarea
    if (isset($_POST['actualizar']) && isset($_POST['id']) && isset($_POST['estado'])) {
        // Obtiene el ID de la tarea y el nuevo estado
        $id = intval($_POST['id']);
        $estado = trim($_POST['estado']); // Asegura que 'estado' sea una cadena limpia

        // Verifica que el estado esté en los valores permitidos
        if (in_array($estado, ['Sin hacer', 'Pendiente', 'Hecha'])) {
            // Intenta actualizar el estado de la tarea a través del método estático 'actualizarEstado'
            if (Tarea::actualizarEstado($id, $estado)) {
                // Si se actualiza correctamente, redirige a la página de tareas
                header("Location: ../vista/tareas.php");
                exit; // Detiene la ejecución del script
            } else {
                // Si hay un error al actualizar el estado, muestra un mensaje de error
                echo "Error al actualizar el estado de la tarea.";
            }
        } else {
            // Si el estado no es válido, muestra un mensaje de error
            echo "Estado inválido.";
        }
    }
}

// Lógica para obtener todas las tareas del usuario cuando se hace una solicitud GET
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['listar'])) {
    // Obtiene las tareas del usuario desde la base de datos usando el método estático 'obtenerPorUsuario'
    $tareas = Tarea::obtenerPorUsuario($usuario_id);

    // Configura la cabecera para indicar que se está enviando JSON
    header('Content-Type: application/json');

    // Convierte las tareas obtenidas a formato JSON y las envía al cliente
    echo json_encode($tareas);
    exit; // Detiene la ejecución del script
}
?>






