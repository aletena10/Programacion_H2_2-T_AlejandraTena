<!DOCTYPE html>
<html>
<head>
    <title>Registro</title> <!-- Título de la página que aparece en la pestaña del navegador -->
    <link rel="stylesheet" href="../css/estilos.css"> <!-- Enlace a la hoja de estilos CSS para aplicar el diseño a la página -->
</head>
<body>
    <h2>Registro de Usuario</h2> <!-- Encabezado que indica que es la página de registro -->

    <!-- Formulario para el registro de un nuevo usuario -->
    <form action="../controlador/usuarioController.php" method="POST"> <!-- El formulario envía los datos al controlador de usuario -->
        <input type="text" name="nombre" placeholder="Nombre" required> <!-- Campo para ingresar el nombre del usuario -->
        <input type="email" name="email" placeholder="Correo Electrónico" required> <!-- Campo para ingresar el correo electrónico del usuario -->
        <input type="password" name="password" placeholder="Contraseña" required> <!-- Campo para ingresar la contraseña del usuario -->
        
        <!-- Botón para enviar el formulario con los datos de registro -->
        <button type="submit" name="registro">Registrarse</button>
    </form>

    <!-- Enlace para redirigir al usuario a la página de inicio de sesión si ya tiene una cuenta -->
    <a href="login.php">¿Ya tienes cuenta? Inicia sesión</a>
</body>
</html>

