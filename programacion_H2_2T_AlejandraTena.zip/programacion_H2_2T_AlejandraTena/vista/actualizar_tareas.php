<?php
// Establece una conexión a la base de datos
$conn = new mysqli("localhost", "root", "curso", "gestor_tareas");

// Verifica si hubo un error en la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Verifica si el formulario fue enviado mediante el método POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoge los valores del formulario (ID de la tarea y el nuevo estado)
    $id = $_POST["id"];
    $estado = $_POST["estado"];

    // Consulta SQL para actualizar el estado de la tarea
    $sql = "UPDATE tareas SET estado='$estado' WHERE id=$id";
    
    // Ejecuta la consulta y verifica si la actualización fue exitosa
    if ($conn->query($sql) === TRUE) {
        // Si la actualización es exitosa, redirige a la página de tareas
        header("Location: tareas.php");
    } else {
        // Si hubo un error en la consulta, muestra el mensaje de error
        echo "Error al actualizar: " . $conn->error;
    }
}

// Cierra la conexión con la base de datos
$conn->close();
?>
