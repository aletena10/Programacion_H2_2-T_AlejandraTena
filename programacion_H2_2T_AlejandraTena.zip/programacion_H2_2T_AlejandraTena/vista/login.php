<?php
session_start(); // Inicia una nueva sesión o reanuda una sesión existente
// Verifica si ya hay un usuario logueado en la sesión
if (isset($_SESSION['usuario'])) {
    // Si el usuario ya está logueado, lo redirige a la página de dashboard
    header("Location: dashboard.php");
    exit; // Detiene la ejecución del script después de la redirección
}
?>

<!DOCTYPE html> <!-- Declaración del tipo de documento HTML5 -->
<html>
<head>
    <title>Login</title> <!-- Título que aparecerá en la pestaña del navegador -->
    <link rel="stylesheet" href="../css/estilos.css"> <!-- Enlace al archivo de estilos CSS para dar formato a la página -->
</head>
<body>
    <h2>Iniciar Sesión</h2> <!-- Título principal de la página, indicando al usuario que es la página de login -->

    <!-- Formulario para ingresar al sistema -->
    <form action="../controlador/usuarioController.php" method="POST">
        <!-- Campo de entrada para el correo electrónico del usuario -->
        <input type="email" name="email" placeholder="Correo Electrónico" required> <!-- El campo es obligatorio, y solo acepta correos electrónicos válidos -->
        
        <!-- Campo de entrada para la contraseña del usuario -->
        <input type="password" name="password" placeholder="Contraseña" required> <!-- El campo es obligatorio, y oculta los caracteres introducidos -->
        
        <!-- Botón de envío para iniciar sesión -->
        <button type="submit" name="login">Ingresar</button> 
    </form>

    <!-- Enlace para redirigir a la página de registro en caso de que el usuario no tenga cuenta -->
    <a href="registro.php">¿No tienes cuenta? Regístrate</a>
</body>
</html>



