<!DOCTYPE html> <!-- Declaración del tipo de documento HTML5 -->
<html lang="es"> <!-- Establece el idioma de la página como español -->
<head>
    <meta charset="UTF-8"> <!-- Establece la codificación de caracteres como UTF-8, lo que permite usar caracteres especiales como acentos -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Configura la página para que sea responsive, adaptándose al tamaño de la pantalla del dispositivo -->
    <title>Gestor de Tareas</title> <!-- Título de la página que aparece en la pestaña del navegador -->
    <link rel="stylesheet" href="../css/estilos.css"> <!-- Enlace al archivo de estilos CSS externo para el diseño de la página -->
</head>
<body>
    <div class="container"> <!-- Contenedor principal para organizar el contenido -->
        <h2>Bienvenido al Gestor de Tareas</h2> <!-- Título de la página que da la bienvenida al usuario -->

        <!-- Enlace para redirigir al usuario a la página de registro -->
        <a href="registro.php">Registrarse</a> 

        <!-- Enlace para redirigir al usuario a la página de inicio de sesión -->
        <a href="login.php">Iniciar Sesión</a> 
    </div>
</body>
</html>


