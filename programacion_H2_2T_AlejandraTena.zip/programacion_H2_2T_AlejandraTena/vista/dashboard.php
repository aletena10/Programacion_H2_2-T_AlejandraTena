<?php
session_start(); // Inicia la sesión para acceder a las variables de sesión

// Verifica si la variable de sesión 'usuario' está configurada (es decir, si el usuario ha iniciado sesión)
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php"); // Redirige al login si no hay sesión activa
    exit(); // Termina la ejecución del script para evitar que se muestre el contenido de la página
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Panel de Tareas</title>
    <link rel="stylesheet" href="../css/estilos.css"> <!-- Enlace al archivo de estilos CSS -->
</head>
<body>
    <!-- Saludo al usuario con su nombre, obtenido desde la sesión -->
    <h2>Bienvenido, <?php echo $_SESSION['usuario']['nombre']; ?></h2>

    <!-- Enlace para gestionar tareas, que lleva a la página tareas.php -->
    <a href="tareas.php">Gestionar Tareas</a>

    <!-- Enlace para cerrar sesión, que redirige a logout.php -->
    <a href="logout.php">Cerrar Sesión</a>
</body>
</html>

