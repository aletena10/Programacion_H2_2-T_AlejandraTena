<?php
session_start(); // Inicia o reanuda la sesión

// Elimina todas las variables de sesión
session_unset(); 

// Destruye la sesión, lo que también elimina la información guardada en ella
session_destroy(); 

// Redirige al usuario a la página de inicio de sesión (login.php)
header("Location: login.php");
?>


