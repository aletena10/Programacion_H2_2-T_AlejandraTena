<?php
session_start(); // Inicia la sesión o recupera la sesión activa
require_once "../modelo/tarea.php"; // Incluye el archivo que contiene la clase Tarea para interactuar con las tareas

// Verifica si el usuario no está autenticado, si es así, redirige al login
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}

// Obtiene las tareas asociadas al usuario actual desde la base de datos
$tareas = Tarea::obtenerPorUsuario($_SESSION['usuario']['id']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"> <!-- Define la codificación de caracteres -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Establece el viewport para diseño adaptativo -->
    <title>Mis Tareas</title> <!-- Título de la página que aparece en la pestaña del navegador -->
    <link rel="stylesheet" href="../css/estilos.css"> <!-- Vincula la hoja de estilos CSS -->
    <script src="../js/script.js" defer></script> <!-- Vincula el archivo de JavaScript que se cargará después de que el contenido HTML esté listo -->
</head>
<body>
    <h2>Lista de Tareas</h2> <!-- Título principal de la página -->

    <!-- Formulario para agregar una nueva tarea -->
    <form action="../controlador/TareasController.php" method="POST">
        <input type="text" name="titulo" placeholder="Nueva tarea" required> <!-- Campo para ingresar el título de la tarea -->
        <button type="submit" name="agregar">Agregar</button> <!-- Botón para agregar la tarea -->
    </form>

    <!-- Lista de tareas -->
    <ul id="lista-tareas">
        <?php foreach ($tareas as $tarea): ?> <!-- Itera sobre cada tarea obtenida -->
            <li>
                <?php echo htmlspecialchars($tarea['titulo']); ?> <!-- Muestra el título de la tarea, asegurándose de escapar caracteres especiales para evitar vulnerabilidades -->
                
                <!-- Formulario para actualizar el estado de la tarea -->
                <form action="../controlador/TareasController.php" method="POST" style="display:inline;">
                    <input type="hidden" name="id" value="<?php echo $tarea['id']; ?>"> <!-- Campo oculto para pasar el ID de la tarea -->
                    
                    <?php $estado = $tarea['estado'] ?? 'Sin hacer'; ?> <!-- Establece el estado de la tarea, si no existe lo inicializa como 'Sin hacer' -->

                    <!-- Selección del estado de la tarea -->
                    <select name="estado">
                        <option value="Sin hacer" <?php echo ($estado == 'Sin hacer') ? 'selected' : ''; ?>>Sin hacer</option> <!-- Estado 'Sin hacer' -->
                        <option value="Pendiente" <?php echo ($estado == 'Pendiente') ? 'selected' : ''; ?>>Pendiente</option> <!-- Estado 'Pendiente' -->
                        <option value="Hecha" <?php echo ($estado == 'Hecha') ? 'selected' : ''; ?>>Hecha</option> <!-- Estado 'Hecha' -->
                     </select>
                </form>

                <!-- Formulario para eliminar la tarea -->
                <form action="../controlador/TareasController.php" method="POST" style="display:inline;">
                    <input type="hidden" name="id" value="<?php echo $tarea['id']; ?>"> <!-- Campo oculto para pasar el ID de la tarea -->
                    <button type="submit" name="eliminar">Eliminar</button> <!-- Botón para eliminar la tarea -->
                </form>
            </li>
        <?php endforeach; ?> <!-- Finaliza el bucle que recorre las tareas -->
    </ul>

    <!-- Enlace para volver al panel de control -->
    <a href="dashboard.php">Volver</a>
</body>
</html>

