<?php
// Requiere el archivo de conexión para poder interactuar con la base de datos
require_once __DIR__ . "/../conexion/conexion.php";

class Tarea {
    // Método estático para obtener todas las tareas de un usuario
    public static function obtenerPorUsuario($usuario_id) {
        // Se crea una instancia de la clase Conexion para conectarse a la base de datos
        $db = new Conexion();
        $conexion = $db->conectar();
        
        // Consulta SQL para obtener todas las tareas de un usuario específico
        $sql = "SELECT * FROM tareas WHERE usuario_id = ?";
        
        // Preparar la consulta SQL
        $stmt = $conexion->prepare($sql);
        
        // Vincula el parámetro de la consulta (id de usuario) al parámetro de la consulta
        $stmt->bind_param("i", $usuario_id);
        
        // Ejecuta la consulta
        $stmt->execute();
        
        // Devuelve todos los resultados en un formato asociativo
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    // Método estático para agregar una tarea a un usuario
    public static function agregar($usuario_id, $titulo) {
        // Crea una nueva instancia de la conexión con la base de datos
        $db = new Conexion();
        $conexion = $db->conectar();
    
        // Verificar si el usuario existe antes de agregar la tarea
        $sql_check = "SELECT id FROM usuarios WHERE id = ?";
        $stmt_check = $conexion->prepare($sql_check);
        $stmt_check->bind_param("i", $usuario_id);
        $stmt_check->execute();
        $stmt_check->store_result();
    
        // Si no se encuentra el usuario, se devuelve un error
        if ($stmt_check->num_rows == 0) {
            return "Error: El usuario no existe.";
        }
    
        // Cierra la consulta de verificación
        $stmt_check->close();
    
        // Si el usuario existe, agrega la tarea a la base de datos
        $sql = "INSERT INTO tareas (usuario_id, titulo) VALUES (?, ?)";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("is", $usuario_id, $titulo);
        
        // Ejecuta la consulta para insertar la tarea
        return $stmt->execute();
    }
    
    // Método estático para eliminar una tarea
    public static function eliminar($id) {
        // Crea una nueva instancia de la conexión con la base de datos
        $db = new Conexion();
        $conexion = $db->conectar();
        
        // Consulta SQL para eliminar una tarea por su ID
        $sql = "DELETE FROM tareas WHERE id = ?";
        $stmt = $conexion->prepare($sql);
        
        // Vincula el parámetro del ID a la consulta SQL
        $stmt->bind_param("i", $id);
        
        // Ejecuta la consulta para eliminar la tarea
        return $stmt->execute();
    }

    // Método estático para actualizar el estado de una tarea
    public static function actualizarEstado($id, $estado) {
        // Establece una nueva conexión con la base de datos
        $conn = new mysqli("localhost", "root", "curso", "gestor_tareas");
        
        // Verifica si la conexión fue exitosa
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }
    
        // Consulta SQL para actualizar el estado de una tarea
        $stmt = $conn->prepare("UPDATE tareas SET estado = ? WHERE id = ?");
        
        // Vincula los parámetros de la consulta (estado y ID de la tarea)
        $stmt->bind_param("si", $estado, $id);
        
        // Ejecuta la consulta para actualizar el estado de la tarea
        $stmt->execute();
        
        // Verifica si se actualizó alguna fila en la base de datos
        $success = $stmt->affected_rows > 0; // Si se actualizó al menos una fila, es exitoso
    
        // Cierra la declaración y la conexión
        $stmt->close();
        $conn->close();
        
        // Devuelve si la actualización fue exitosa o no
        return $success;
    }
}


?>
