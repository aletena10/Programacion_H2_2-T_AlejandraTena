<?php
// Requiere el archivo de conexión para poder interactuar con la base de datos
require_once __DIR__ . "/../conexion/conexion.php";

class Usuario {
    // Método estático para registrar un nuevo usuario
    public static function registrar($nombre, $email, $password) {
        // Crea una nueva instancia de la clase Conexion para conectarse a la base de datos
        $db = new Conexion();
        $conexion = $db->conectar();

        // Verifica si el email ya está registrado en la base de datos
        $sql_check = "SELECT id FROM usuarios WHERE email = ?";
        $stmt_check = $conexion->prepare($sql_check);
        $stmt_check->bind_param("s", $email);
        $stmt_check->execute();
        $stmt_check->store_result();
        
        // Si el email ya existe, retorna un mensaje de error
        if ($stmt_check->num_rows > 0) {
            return "Error: El correo ya está registrado.";
        }

        // Cierra la consulta de verificación
        $stmt_check->close();

        // Si el email no existe, se procede a insertar el nuevo usuario
        // Se hace un hash de la contraseña para asegurar su seguridad
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("sss", $nombre, $email, $hash);
        
        // Ejecuta la consulta para insertar el nuevo usuario en la base de datos
        if ($stmt->execute()) {
            return "Usuario registrado con éxito.";
        } else {
            return "Error al registrar usuario.";
        }
    }

    // Método estático para autenticar un usuario durante el login
    public static function autenticar($email, $password) {
        // Crea una nueva instancia de la clase Conexion para conectarse a la base de datos
        $db = new Conexion();
        $conexion = $db->conectar();
        
        // Consulta SQL para obtener los detalles del usuario con el email proporcionado
        $sql = "SELECT * FROM usuarios WHERE email = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        
        // Obtener el resultado de la consulta
        $resultado = $stmt->get_result();
        $usuario = $resultado->fetch_assoc();
        
        // Verifica si el usuario existe y si la contraseña es correcta
        return $usuario && password_verify($password, $usuario['password']) ? $usuario : false;
    }
}

?>




