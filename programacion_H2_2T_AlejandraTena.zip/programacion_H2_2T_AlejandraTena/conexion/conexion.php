<?php
class Conexion {
    // Atributos privados para almacenar los datos de conexión
    private $servidor = 'localhost';  // Dirección del servidor de la base de datos (localhost significa que está en la misma máquina)
    private $usuario = 'root';        // Nombre de usuario para acceder a la base de datos
    private $password = 'curso';      // Contraseña del usuario para la base de datos
    private $base_datos = 'gestor_tareas';  // Nombre de la base de datos a la que nos queremos conectar
    public $conexion;  // Propiedad pública para almacenar la conexión a la base de datos

    // Constructor que se ejecuta al crear una nueva instancia de la clase
    public function __construct() {
        // Intentar establecer la conexión con la base de datos
        $this->conexion = new mysqli($this->servidor, $this->usuario, $this->password, $this->base_datos);

        // Verificar si hay algún error en la conexión
        if ($this->conexion->connect_error) {
            // Si ocurre un error, detener el script y mostrar el mensaje de error
            die("Error de conexión: " . $this->conexion->connect_error);
        }
    }

    // Método para devolver la instancia de la conexión
    public function conectar() {
        return $this->conexion;  // Devuelve el objeto de conexión
    }

    // Método para cerrar la conexión a la base de datos
    public function cerrar() {
        $this->conexion->close();  // Cierra la conexión
    }
}
?>


