// Espera a que el DOM se haya cargado completamente antes de ejecutar el código
document.addEventListener("DOMContentLoaded", function () {
    
    // Selecciona todos los botones con la clase 'eliminar-btn'
    const botonesEliminar = document.querySelectorAll(".eliminar-btn");

    // Recorre todos los botones de eliminar
    botonesEliminar.forEach(boton => {
        
        // Agrega un evento 'click' a cada botón
        boton.addEventListener("click", function () {
            
            // Obtiene el valor del atributo 'data-id' del botón, que corresponde al ID de la tarea
            const id = this.getAttribute("data-id");

            // Muestra un cuadro de confirmación antes de proceder con la eliminación
            if (confirm("¿Estás seguro de eliminar esta tarea?")) {

                // Crea un nuevo formulario para enviar la solicitud de eliminación
                const form = document.createElement("form");
                form.method = "POST"; // Establece el método del formulario a 'POST'
                form.action = "../controlador/tareaController.php"; // Establece la URL del controlador de tareas

                // Crea un campo de entrada oculto para pasar el ID de la tarea
                const inputId = document.createElement("input");
                inputId.type = "hidden"; // Campo de tipo oculto
                inputId.name = "id"; // Nombre del campo, que será 'id'
                inputId.value = id; // Asigna el valor del ID de la tarea

                // Crea un campo de entrada oculto para indicar que la acción es una eliminación
                const inputEliminar = document.createElement("input");
                inputEliminar.type = "hidden"; // Campo de tipo oculto
                inputEliminar.name = "eliminar"; // Nombre del campo, que será 'eliminar'
                inputEliminar.value = "1"; // Valor que indica la acción de eliminar

                // Agrega los campos de entrada al formulario
                form.appendChild(inputId);
                form.appendChild(inputEliminar);

                // Añade el formulario al cuerpo del documento
                document.body.appendChild(form);

                // Envía el formulario para que se procese la eliminación
                form.submit();
            }
        });
    });
});

